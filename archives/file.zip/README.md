# Test
first repository

Learnt about repository, branch and commit.

Repository    : New Project
branch        : different environments like development, production etc. Here "master" is the main branch.
                Now we are in different branch. Until we commit, these changes will not be reflected in master branch.
pull requests : Do this when you want to merge branch and master code. You can see the changes whatever you have done.
merge         : By review of your team members, it can be merged finally.
